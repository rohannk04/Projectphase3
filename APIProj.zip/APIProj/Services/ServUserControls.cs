﻿using BankAPI.Models;
using BankAPI.Repositary.Admin;
using BankAPI.Repositary.Custom;

using BankAPI.Models;
namespace BankAPI.Services
{
    public class ServUserControls : IServUserControls
    {
        IRepoUserControls RUser;
        

        public ServUserControls(IRepoUserControls RUser)
        {
            this.RUser = RUser;

        }

        public async Task CreateAccount(Account account)
        {
            await RUser.CreateAccount(account);
        }
        public async Task Deposit(float amount, int Accn)
        {
            await RUser.Deposit(amount, Accn);
        }
        public async Task RecordTransactions(int AccountNumber, string username, float amount, string TransactionType)
        {
            RUser.RecordTransactions( AccountNumber, username, amount, TransactionType);
        }

        public async Task Withdraw(float amount, int Accn)
        {
            await RUser.Withdraw(amount, Accn);
        }

        public async Task Transfer(float amount, int SenderAccno, int RecieverAccno)
        {
            await RUser.Transfer(amount, SenderAccno, RecieverAccno);
        }

        public List<Transaction> TransactionDetails(int Accno)
        {
            return RUser.TransactionDetails(Accno);
        }
    }
}
