﻿namespace BankAPI.Services
{
    public interface IServAdminControls
    {
        public Task Approve(string username);
        public Task Block(string username);
        public Task UnBlock(string username);
    }
}
