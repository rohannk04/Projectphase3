﻿using System;
using System.Collections.Generic;

namespace BankAPI.Models;

public partial class AdminDatum
{
    public string UserName { get; set; } = null!;

    public string? Password { get; set; }
}
