﻿using BankAPI.Models;
namespace BankAPI.Repositary.Custom
{
    public interface IRepoUserControls
    {
        public Task CreateAccount(Account account);
        public Task Deposit(float amount, int Accn);
        public void RecordTransactions(int Accn, string username, float amount, string TransactionType);
        public Task Withdraw(float amount, int Accn);
        public Task Transfer(float amount, int SenderAccno, int RecieverAccno);
        public List<Transaction> TransactionDetails(int Accno);
    }
}
