﻿using BankAPI.Models;
using BankAPI.Repositary.Admin;
using Microsoft.EntityFrameworkCore;

namespace BankAPI.Repositary.Custom
{
    public class RepoUserControls : IRepoUserControls
    {
        private readonly UnionBankContext db;

        public RepoUserControls(UnionBankContext db)
        {
            this.db = db;
        }

        public async Task CreateAccount(Account account)
        {
            Random rand = new Random();
            account.BlockStatus = true;
            account.ApproveStatus = true;
            account.AccountNumber = rand.Next();    
            await db.Accounts.AddAsync(account);
            await db.SaveChangesAsync();
        }
        public async Task Deposit(float amount, int Accn)
        {
            var account = await(from data in db.Accounts where data.AccountNumber == Accn select data).SingleOrDefaultAsync();

            if (account != null)
            {
                RecordTransactions(Accn, "30", amount, "Deposit");
                account.CurrentBalance = account.CurrentBalance + amount;
                db.Accounts.Update(account);
                await db.SaveChangesAsync();
            }

        }


        public void RecordTransactions(int AccountNumber, string username, float amount, string TransactionType)
        {
            Transaction transaction = new Transaction();
            transaction.AccountNumber = AccountNumber;
            transaction.Amount = amount;
            DateTime date = DateTime.Now;

            transaction.TransactionDate = date;
            transaction.TransactionType = TransactionType;

            db.Transactions.Add(transaction);
            db.SaveChanges();
        }

        public async Task Withdraw(float amount, int Accn)
        {
            var account = (from data in db.Accounts where data.AccountNumber == Accn select data).SingleOrDefault();

            if (account != null)
            {
                
                RecordTransactions(Accn, account.UserName, amount, "Withdraw");
                account.CurrentBalance = account.CurrentBalance - amount;
                db.Accounts.Update(account);
                await db.SaveChangesAsync();
                
            }
      
        }
        
        public async Task Transfer(float amount,int SenderAccno, int RecieverAccno)
        {
            var account1 = (from data in db.Accounts where data.AccountNumber == SenderAccno select data).SingleOrDefault();
            var account2 = (from data in db.Accounts where data.AccountNumber == RecieverAccno select data).SingleOrDefault();

            if (account1 != null)
            {
                RecordTransactions(SenderAccno, account1.UserName, amount, "Transfer");
                RecordTransactions(RecieverAccno, account2.UserName, amount, "Transfer");
                account1.CurrentBalance = account1.CurrentBalance - amount;
                account2.CurrentBalance = account2.CurrentBalance + amount;
                db.Accounts.Update(account1);
                db.Accounts.Update(account2);
                db.SaveChanges();

            }
        }

        public List<Transaction>TransactionDetails(int Accno)
        {
            List<Transaction> List = new List<Transaction>();
            List = (from data in db.Transactions where data.AccountNumber == Accno select data).ToList();
            return List;
        }
    }
}

           
        
    


