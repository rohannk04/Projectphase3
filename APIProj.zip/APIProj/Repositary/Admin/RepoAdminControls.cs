﻿using BankAPI.Models;
using Microsoft.Extensions.Primitives;

namespace BankAPI.Repositary.Admin
{
    public class RepoAdminControls: IRepoAdminControls
    {
        private readonly UnionBankContext db = new UnionBankContext();

        public async Task Approve(string username)
        {
            Account customer = db.Accounts.Find(username);

            if (customer != null)
            {
            customer.ApproveStatus = true;
            db.Accounts.Update(customer);
            db.SaveChangesAsync();
            }
        }

        public async Task Block(string username)
        {
            Account customer = db.Accounts.Find(username);

            if (customer != null)
            {
                customer.BlockStatus = false;
                db.Accounts.Update(customer);
                db.SaveChangesAsync();
            }
        }

        public async Task UnBlock(string username)
        {
            Account customer = db.Accounts.Find(username);

            if (customer != null)
            {
                customer.BlockStatus = true;
                db.Accounts.Update(customer);
                db.SaveChangesAsync();
            }
        }
    }
}
